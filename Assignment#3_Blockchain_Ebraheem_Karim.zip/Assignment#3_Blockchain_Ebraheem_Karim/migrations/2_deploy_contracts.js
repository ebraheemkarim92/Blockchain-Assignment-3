
const MultiplicationGame = artifacts.require("MultiplicationGame");

module.exports = function (deployer) {
    deployer.deploy(MultiplicationGame);
};
