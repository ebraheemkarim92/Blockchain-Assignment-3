App = {
  web3Provider: null,
  contracts: {},

  init: async function() {
    return await App.initWeb3();
  },

  initWeb3: async function() {
    // Modern dapp browsers...
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      try {
        // Request account access
        await window.ethereum.enable();
      } catch (error) {
        // User denied account access...
        console.error("User denied account access");
      }
    }
    // Legacy dapp browsers...
    else if (window.web3) {
      App.web3Provider = window.web3.currentProvider;
    }
    // If no injected web3 instance is detected, fall back to Ganache
    else {
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
    }
    web3 = new Web3(App.web3Provider);

    return App.initContract();
  },

  initContract: function() {
    $.getJSON('MultiplicationGame.json', function(data) {
      // Get the necessary contract artifact file and instantiate it with @truffle/contract
      var MultiplicationGameArtifact = data;
      App.contracts.MultiplicationGame = TruffleContract(MultiplicationGameArtifact);

      // Set the provider for our contract
      App.contracts.MultiplicationGame.setProvider(App.web3Provider);

      // Use our contract to retrieve and update the player's score
      return App.updateScore();
    });

    return App.bindEvents();
  },

  bindEvents: function() {
    $(document).on('click', '#connectBtn', App.initWeb3);
    $(document).on('click', '#startBtn', App.handleStartGame);
    $(document).on('click', '#submitBtn', App.handleSubmitAnswer);
  },

  updateScore: function() {
    var gameInstance;

    web3.eth.getAccounts(function(error, accounts) {
      if (error) {
        console.log(error);
        return;
      }

      var account = accounts[0];
      if (account) {
        $('#accountDisplay').text('Connected: ' + account.substring(0, 6) + '...' + account.substring(38));
        $('#connectBtn').text('Connected');
        $('#startBtn').prop('disabled', false);
      }

      App.contracts.MultiplicationGame.deployed().then(function(instance) {
        gameInstance = instance;
        return gameInstance.getScore.call(account);
      }).then(function(score) {
        $('#scoreDisplay').text('Score: ' + score.toString());
      }).catch(function(err) {
        console.log(err.message);
      });
    });
  },

  handleStartGame: function(event) {
    event.preventDefault();

    var gameInstance;

    web3.eth.getAccounts(function(error, accounts) {
      if (error) {
        console.log(error);
        return;
      }

      var account = accounts[0];
      $('#status').text('Starting game... Please confirm transaction in MetaMask.');

      App.contracts.MultiplicationGame.deployed().then(function(instance) {
        gameInstance = instance;
        return gameInstance.startGame({ from: account });
      }).then(function(result) {
        $('#status').text('New problem generated!');
        return gameInstance.getCurrentProblem.call({ from: account });
      }).then(function(problem) {
        var n1 = problem[0].toString();
        var n2 = problem[1].toString();
        $('#problemDisplay').text('Problem: What is ' + n1 + ' × ' + n2 + '?');
        $('#answerSection').show();
      }).catch(function(err) {
        $('#status').text('Error: ' + err.message);
      });
    });
  },

  handleSubmitAnswer: function(event) {
    event.preventDefault();

    var answer = $('#answerInput').val();
    if (!answer) {
      alert('Please enter an answer!');
      return;
    }

    var gameInstance;

    web3.eth.getAccounts(function(error, accounts) {
      if (error) {
        console.log(error);
        return;
      }

      var account = accounts[0];
      $('#status').text('Submitting answer... Confirm in MetaMask.');

      App.contracts.MultiplicationGame.deployed().then(function(instance) {
        gameInstance = instance;
        return gameInstance.submitAnswer(answer, { from: account });
      }).then(function(result) {
        $('#status').text('Answer processed successfully!');
        $('#answerSection').hide();
        $('#answerInput').val('');
        $('#problemDisplay').text("Problem: Click 'Start Game' to play again.");
        return App.updateScore();
      }).catch(function(err) {
        $('#status').text('Error: ' + err.message);
      });
    });
  }
};

$(function() {
  $(window).load(function() {
    App.init();
  });
});
