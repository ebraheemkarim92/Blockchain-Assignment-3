// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract MultiplicationGame {
    mapping(address => uint256) public scores;
    mapping(address => uint256) public currentMultiplier1;
    mapping(address => uint256) public currentMultiplier2;

    event GameStarted(address indexed player, uint256 num1, uint256 num2);
    event AnswerSubmitted(address indexed player, bool correct, uint256 newScore);

    // --- WRITE FUNCTIONS ---

    // 1. Start a new round by generating two random numbers
    function startGame() external {
        uint256 num1 = (uint256(keccak256(abi.encodePacked(block.timestamp, msg.sender, block.difficulty))) % 9) + 2;
        uint256 num2 = (uint256(keccak256(abi.encodePacked(block.number, msg.sender))) % 9) + 2;
        
        currentMultiplier1[msg.sender] = num1;
        currentMultiplier2[msg.sender] = num2;

        emit GameStarted(msg.sender, num1, num2);
    }

    // 2. Submit the answer to the current problem
    function submitAnswer(uint256 answer) external {
        uint256 n1 = currentMultiplier1[msg.sender];
        uint256 n2 = currentMultiplier2[msg.sender];
        require(n1 > 0 && n2 > 0, "Please start a game first!");

        bool isCorrect = (answer == n1 * n2);
        if (isCorrect) {
            scores[msg.sender] += 10;
        }

        // Reset problem round
        currentMultiplier1[msg.sender] = 0;
        currentMultiplier2[msg.sender] = 0;

        emit AnswerSubmitted(msg.sender, isCorrect, scores[msg.sender]);
    }

    // --- READ FUNCTIONS ---

    // 3. Get player's total score
    function getScore(address player) external view returns (uint256) {
        return scores[player];
    }

    // 4. Get active math problem for the caller
    function getCurrentProblem() external view returns (uint256, uint256) {
        return (currentMultiplier1[msg.sender], currentMultiplier2[msg.sender]);
    }
}